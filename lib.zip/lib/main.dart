import 'package:flutter/material.dart';
import 'package:flutter_application_user_management_2/Presentation/home_screen.dart';
import 'package:flutter_application_user_management_2/Presentation/login_screen.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(home: ScreenLogin());
  }
}
