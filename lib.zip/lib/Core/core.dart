import 'package:flutter/material.dart';

ValueNotifier<bool> isEditableNotifier = ValueNotifier(false);
